# pip install pyzmq cbor keyboard
from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import keyboard

# Connecting to the CoppeliaSim server
client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')

# Get the handles for the sliders (prismatic joints)
cw = sim.getObject('/R_joint')
ccw = sim.getObject('/L_joint')
slider = sim.getObject('/Prismatic_joint')

# Starting the simulation
sim.startSimulation()
print('Simulation started')

# Main control loop
def main():
    # Keep running until simulation is stopped
    while True:
        # Controls for cw and ccw joints
        if keyboard.is_pressed('p'):  # Move cw slider to -0.25 position
            print("p is pressed")
            sim.setJointTargetPosition(cw, -0.25)

        if keyboard.is_pressed('l'):  # Reset cw slider to the original position
            print("l is pressed")
            sim.setJointTargetPosition(cw, 0.0)

        if keyboard.is_pressed('w'):  # Move ccw slider to -0.28 position
            print("w is pressed")
            sim.setJointTargetPosition(ccw, -0.28)

        if keyboard.is_pressed('s'):  # Reset ccw slider to the original position
            print("s is pressed")
            sim.setJointTargetPosition(ccw, 0.0)

        # Controls for the Prismatic_joint
        if keyboard.is_pressed('E'):  # Move slider to -0.15 position
            print("E is pressed")
            sim.setJointTargetPosition(slider, 0.25)

        if keyboard.is_pressed('D'):  # Reset slider to the original position
            print("D is pressed")
            sim.setJointTargetPosition(slider, 0.0)

        # Stop the simulation
        if keyboard.is_pressed('t'):  # Stop the simulation
            print("t is pressed - stopping simulation")
            sim.stopSimulation()
            break

# Start the main control loop
main()
